Práctica 2 realizada por:
  - Moisés Moyano Cejudo
  - Alba Palomino Jiménez
  - Carlos Rivero Talavera
  - Silvia Roldán Flores
  
 Para ejecutar los ficheros compilados a través de una terminal, se ha de ejecutar el siguiente comando:
 	
 	java -jar practica2.jar
   	
  Asimismo, es posible registrarse si no está previamente en el sistema. En caso de estarlo, basta con iniciar sesión con el email de usuario con el que se registró.

  El sistema permite listar a los usuarios del mismo, así como añadir, modificar y eliminar usuarios del propio sistema.